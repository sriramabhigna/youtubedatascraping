from googleapiclient.discovery import build
import pandas as pd
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api.formatters import SRTFormatter

# Define your YouTube API key here
YOUTUBE_API_KEY = 'AIzaSyCLMK9cmnu3oL0QmFgy5v83QmGVhbD2-yo'  # Replace with your actual API Key

# Build the YouTube API client
youtube = build('youtube', 'v3', developerKey=YOUTUBE_API_KEY)

def get_video_data(genre, max_results=10):
    # Fetch the top videos based on the genre
    videos = []
    next_page_token = None
    
    while len(videos) < max_results:
        search_request = youtube.search().list(
            part="snippet",
            type="video",
            q=genre,
            order="viewCount",  # Sort by view count
            maxResults=50,  # API can return a maximum of 50 results per request
            pageToken=next_page_token  # Use the nextPageToken for pagination
        )
        
        search_response = search_request.execute()

        # Extract video details
        for item in search_response.get('items', []):
            video_id = item['id']['videoId']
            video_url = f'https://www.youtube.com/watch?v={video_id}'
            title = item['snippet'].get('title', 'N/A')
            description = item['snippet'].get('description', 'N/A')
            channel_title = item['snippet'].get('channelTitle', 'N/A')
            published_at = item['snippet'].get('publishedAt', 'N/A')
            video_category = item['snippet'].get('categoryId', 'N/A')  # YouTube Category ID
            location = item['snippet'].get('location', 'N/A')  # Location (if available)

            # Fetch detailed video data
            video_request = youtube.videos().list(
                part="snippet,statistics,contentDetails",  # Include snippet to fetch tags and contentDetails for duration
                id=video_id
            )
            video_response = video_request.execute()
            
            # Extract statistics and tags
            view_count = video_response['items'][0]['statistics'].get('viewCount', 0)
            comment_count = video_response['items'][0]['statistics'].get('commentCount', 0)
            tags = video_response['items'][0]['snippet'].get('tags', [])  # Fetch keyword tags
            
            # Fetch video duration
            video_duration = video_response['items'][0]['contentDetails'].get('duration', 'Not Available')
            
            # Check if captions are available
            captions_available = False
            captions_text = ''
            try:
                transcript = YouTubeTranscriptApi.get_transcript(video_id)
                captions_available = True
                
                # Convert transcript to SRT format
                formatter = SRTFormatter()
                captions_text = formatter.format_transcript(transcript)  # Get full captions text
            except:
                captions_text = "No captions available"
            
            # Store video details, ensure all list data is converted to string
            video_data = {
                'Video URL': video_url,
                'Title': title,
                'Description': description,
                'Channel Title': channel_title,
                'Keyword Tags': ', '.join(tags),  # Convert list to comma-separated string
                'YouTube Category': video_category,  # Category ID
                'Topic Details': ', '.join(tags),  # Topic Details as comma-separated string
                'Published At': published_at,
                'Duration': video_duration,
                'View Count': view_count,
                'Comment Count': comment_count,
                'Captions Available': captions_available,
                'Captions Text': captions_text,
                'Location': location  # Location of the video recording
            }
            videos.append(video_data)

            # Stop if we've reached the desired number of results
            if len(videos) >= max_results:
                break
        
        # Update the nextPageToken to get the next page of results
        next_page_token = search_response.get('nextPageToken')

        # If there's no nextPageToken, stop pagination
        if not next_page_token:
            break

    return videos

def save_to_csv(videos, filename='new.csv'):
    # Convert the list of video data into a pandas DataFrame
    df = pd.DataFrame(videos)
    
    # Save the DataFrame to a CSV file
    df.to_csv(filename, index=False)
    print(f"Data saved to {filename}")

def main():
    genre = input("Enter the genre: ")
    
    # Get video data for the specified genre
    videos = get_video_data(genre)
    
    # Save the video data to a CSV file
    save_to_csv(videos)

if __name__ == "__main__":
    main()